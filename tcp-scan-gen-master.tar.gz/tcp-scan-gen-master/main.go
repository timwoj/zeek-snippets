package main

import (
	"bufio"
	"flag"
	"log"
	"net"
	"os"
	"time"

	"github.com/google/gopacket"
	"github.com/google/gopacket/layers"
	"github.com/google/gopacket/pcapgo"
)

var (
	snapshotLen uint32 = 1500
)

func main() {
	var numPackets int
	flag.IntVar(&numPackets, "packets", 1_000, "Number of packets")
	flag.Parse()

	// Open output pcap file and write header
	f, err := os.Create("scan.pcap")
	if err != nil {
		log.Fatal(err)
	}
	defer f.Close()

	bf := bufio.NewWriter(f)
	defer bf.Flush()

	w := pcapgo.NewWriter(bf)
	w.WriteFileHeader(snapshotLen, layers.LinkTypeEthernet)

	sMac, _ := net.ParseMAC("00:00:00:00:00:01")
	dMac, _ := net.ParseMAC("00:00:00:00:00:02")
	sIP := net.ParseIP("10.0.0.1")

	opts := gopacket.SerializeOptions{
		FixLengths:       true,
		ComputeChecksums: true,
	}

	buf := gopacket.NewSerializeBuffer()
	start := time.Now()
	for i := 0; i < numPackets; i++ {
		sIP = net.IPv4(10, byte((i/256/256)%256), byte((i/256)%256), 10)
		dIP := net.IPv4(10, byte((i/256/256)%256), byte((i/256)%256), byte(i%256))
		sPort := (i % 32000) + 32000
		// Construct all the network layers we need.
		eth := layers.Ethernet{
			SrcMAC:       sMac,
			DstMAC:       dMac,
			EthernetType: layers.EthernetTypeIPv4,
		}
		ip4 := layers.IPv4{
			SrcIP:    sIP,
			DstIP:    dIP,
			Version:  4,
			TTL:      64,
			Protocol: layers.IPProtocolTCP,
		}
		tcp := layers.TCP{
			SrcPort: layers.TCPPort(sPort),
			DstPort: 23,
			SYN:     true,
			Window:  65535,
		}
		tcp.SetNetworkLayerForChecksum(&ip4)

		if err := gopacket.SerializeLayers(buf, opts, &eth, &ip4, &tcp); err != nil {
			log.Fatal(err)
		}
		bbytes := buf.Bytes()
		ts := start.Add(time.Millisecond * time.Duration(i) / 100)
		ci := gopacket.CaptureInfo{
			Timestamp:     ts,
			CaptureLength: len(bbytes),
			Length:        len(bbytes),
		}
		w.WritePacket(ci, bbytes)
	}
}
